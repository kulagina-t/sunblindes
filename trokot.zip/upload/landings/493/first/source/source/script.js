jQuery(document).ready(function(){
	
	/*
	var l_now = new Date();
	var l_end = new Date(2016,1,15);
	var l_leftBefore = l_end-l_now;
	var l_leftBefore_h = l_leftBefore.toFixed()/3600000;
	var l_leftBefore_d = l_leftBefore_h.toFixed()/24;
	var l_days = Math.floor(l_leftBefore_d);
	var l_hours = Math.floor(l_leftBefore_h) - l_days*24;
	var l_day_text = '';
	if(l_days == 1) l_day_text = l_days+' день';
	if(l_days > 1 && l_days < 5) l_day_text = l_days+' дня';
	if(l_days == 0 || l_days > 4) l_day_text = l_days+' дней';
	var l_hour_text = '';
	if(l_hours == 1 || l_hours == 21) l_hour_text = l_hours+' час';
	if((l_hours > 1 && l_hours < 5) || l_hours > 21) l_hour_text = l_hours+' часа';
	if(l_hours == 0 || (l_hours > 4 && l_hours < 21)) l_hour_text = l_hours+' часов';
	jQuery('#rise_price_pop_up .days').text(l_day_text);
	jQuery('#rise_price_pop_up .hours').text(l_hour_text);
	jQuery('#rise_price_pop_up').delay(2000).fadeIn(500);
	*/
	
	jQuery('.pop_up .close').click(function(){
		var popup = jQuery(this).parents('.pop_up');
		jQuery('.pop_up').fadeOut(200);
		
		return false;
	});	
	
	jQuery('.pop_up').click(function(event){		
		if (!jQuery(event.target).closest('.window').length){
			jQuery('.pop_up').fadeOut(200);
		}
	});	
	
	jQuery('#rise_price_pop_up a.button').click(function(){
		jQuery('html, body').animate({scrollTop: jQuery('.demand_panel').offset().top}, 500);
		jQuery(this).parents('#rise_price_pop_up').hide();
		
		return false;
	});


	$('a[href^="#"]').click(function() {
            var elementClick = $(this).attr("href");
            var destination = $(elementClick).offset().top;
            jQuery("html:not(:animated), body:not(:animated)").animate({
                scrollTop: destination
            }, 800);
            return false;
        });
	
	
});